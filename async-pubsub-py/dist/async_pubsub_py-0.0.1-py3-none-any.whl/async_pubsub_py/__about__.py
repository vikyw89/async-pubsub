# SPDX-FileCopyrightText: 2024-present vikyw89 <vikyw89@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
