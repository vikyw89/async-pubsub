# async-pubsub-py

[![PyPI - Version](https://img.shields.io/pypi/v/async-pubsub-py.svg)](https://pypi.org/project/async-pubsub-py)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/async-pubsub-py.svg)](https://pypi.org/project/async-pubsub-py)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install async-pubsub-py
```

## License

`async-pubsub-py` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
